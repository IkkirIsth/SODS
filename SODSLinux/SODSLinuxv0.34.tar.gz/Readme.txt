Shores of Hazeron Offline Design Studio v0.34 (smooth moves version!) (Release date: February 25, 2012)

Note: You can chage keyboard options by editing config.txt

Use instructions: Draw a room by left-clicking on the roomtype, then left-clicking on the grid to draw edges. Mouse autosnaps to legal angles. 

While drawing, press backspace to delete the latest point, or press spacebar to finish the room and start drawing another one.  Delete an entire room with the delete key.  Illegal rooms
are not saved and are colored a semi-transparent red.
To reselect a room, use the Pick tool on the bottom of the ui buttons (2nd one on the bottom).
To select a specific vertex, use the Vertex Pick tool while a room is selected.  If one is not selected, it attempts to select one at the mouse cursor.

You can flip and rotate designs using the buttons next to save and load.  To move a room, mouse over it and press 'm', and click where you want to drop it.

+ and - on numpad raise and lower the room level (there is no notification of what level you are on).  The UI-buttons also work.

Armorlevel/streamlining: UI buttons work at the top.

To zoom in and out, use page up or page down, or mousewheel up / down.

To pan around, use the arrow keys.  The zoom level effects how fast the pan occurs.  You can also rightclick and drag to pan.

Equipment placeable now is all but vehicles, contrails, emitters, and medical unit types. 


To fill a room with equipment, select the equipment and hover over the room you want to fill and press F. To increase/decrease brushsize, press the <- or +> buttons on the ui window OR press left/right shift.

To change hatch/berth orientation, press right/left alt.

To change turret module, press right/left control.

To save, press the save ui-button on the top left of the buttons section.  There is no options, it simply saves as testSODS.ship.  To clear the design, press the XAX button: THERE IS NO CONFIRM BUTTON RIGHT NOW!

Press Escape for options.

PARTS:
You can add rooms and their equipment to a ship-part (displayed in bottom right) for ease-of-use copying.  To add a room to the part, use the 5th, green button and then click on the part you want to add.  You can then place the part by clicking on the second button OR clicking on the part window and then placing the drawn-part where you want it.  To unselect the part, press spacebar. 

Any room added to the part is added at the same level as its design studio counterpart: You can add multiple rooms at a time and multiple levels at a time, and the currently displayed level is added back to the current level, with all other levels adding above/below.

Parts will eventually be able to be saved/loaded, and usable to place room sets easy for quick design styles. They currently function almost like a whole-nother design studio. NOTE: There are issues placing off-center parts near the edges currently.

You can also flip and rotate parts using buttons in the part-box.

//note: color coding broken at the moment, it simply saves without giving any feedback
Green indicates a successful save.
Grey indicates some rooms were illegal and not saved.
Red indicates no save done. 